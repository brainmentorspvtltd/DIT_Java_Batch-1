import java.util.Stack;

public class StackIntroWithJava {
    public static void main(String[] args) {
        Stack<String> stack = new Stack<>();
        stack.push("hi");
        stack.push("hello");
        stack.push("how");
        stack.push("are");
        stack.push("you ?");

        // push - append element in stack at end
        // pop  - remove element from stack from end
        // peek - return top element

    }
}