class NodeMerge {
    NodeMerge right;
    NodeMerge down;
    int data;
    NodeMerge(int data) {
        this.data = data;
    }
}

public class MergeKLinkedList {
    NodeMerge start, tail;

    NodeMerge merge(NodeMerge start_1, NodeMerge start_2) {
        if(start_1 == null) {
            return start_2;
        }
        if(start_2 == null) {
            return start_1;
        }
        NodeMerge third, temp;
        if(start_1.data < start_2.data) {
            third = start_1;
            start_1 = start_1.down;
        }
        else {
            third = start_2;
            start_2 = start_2.down;
        }

        temp = third;
        while(start_1 != null && start_2 != null) {
            if(start_1.data < start_2.data) {
                temp.down = start_1;
                temp = temp.down;
                start_1 = start_1.down;
            }
            else {
                temp.down = start_2;
                temp = temp.down;
                start_2 = start_2.down;
            }
        }
        temp.down = start_1 !=null ? start_1 : start_2;
        return third;
    }

    void flatten() {
        if(start == null || start.right == null) {
            print_1(start);
            return;
        }
        NodeMerge remaining = start.right;
        NodeMerge newHead = start;
        while(remaining != null) {
            NodeMerge n2 = remaining;
            remaining = remaining.right;
            newHead = merge(newHead, n2);
        }
        print_1(newHead);
    }

    void print_1(NodeMerge start) {
        NodeMerge temp = start;
        while(temp != null) {
            System.out.print(temp.data + ",");
            temp = temp.down;
        }
        System.out.println();
    }

    void add(int data) {
        if(start == null) {
            NodeMerge node = new NodeMerge(data);
            tail = start = node;
        }
        else {
            NodeMerge node = new NodeMerge(data);
            tail.down = node;
            tail = node;
        }
    }

    void print() {
        NodeMerge temp = start;
        while(temp != null) {
            if(temp.down != null) {
                NodeMerge temp2 = temp;
                while(temp2 != null) {
                    System.out.print(temp2.data + ",");
                    temp2 = temp2.down;
                }
                System.out.println();
            }
            temp = temp.right;
        }
    }

    void topAdd(NodeMerge node) {
        if(start == null) {
            tail = start = node;
        }
        else {
            tail.right = node;
            tail = node;
        }
    }

    public static void main(String[] args) {
        MergeKLinkedList np = new MergeKLinkedList();
        np.add(5);
        np.add(7);
        np.add(9);
        np.add(12);

        np.print();

        MergeKLinkedList np2 = new MergeKLinkedList();
        np2.add(13);
        np2.add(15);
        np2.add(19);

        np2.print();
        
        MergeKLinkedList np3 = new MergeKLinkedList();
        np3.add(1);
        np3.add(10);
        np3.add(11);

        np3.print();

        MergeKLinkedList np4 = new MergeKLinkedList();
        np4.topAdd(np.start);
        np4.topAdd(np2.start);
        np4.topAdd(np3.start);

        np4.print();

        np4.flatten();
    }
}