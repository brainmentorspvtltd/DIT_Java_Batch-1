package com.bmpl.chatapp.views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;

public class ChatScreen extends JFrame {
	private JTextField textField;
	
	public ChatScreen() {
		setBounds(100, 100, 904, 512);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 20));
		textArea.setBounds(10, 10, 870, 350);
		getContentPane().add(textArea);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField.setBounds(10, 392, 655, 73);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Send Message");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.setBounds(675, 392, 194, 73);
		getContentPane().add(btnNewButton);

	}

//	public static void main(String[] args) {
//		ChatScreen window = new ChatScreen();
//		window.setVisible(true);
//	}
}
